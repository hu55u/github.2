# github.2
licensing model (1) it is easy to get caught up in code sharing your code isnt everything,though it also important to tell people how they can use that code
